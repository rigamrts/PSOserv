2009.1.7 update before use Description: 
1, Extract the compressed package coverage drop files in that folder to the server "login/drop/" in the document. The configuration client must retain the "Drop" directory and file folders.
2, Use the "PsobbItemsListTool.exe" tool to import "Items.txt" file (PSOBB items data files. can be modified in accordance with its own format) to generate "Items.dll" to the use of new features.
3, Run "PsobbServerConfigApp.exe" to configure your Tethealla PSOBB server.
4, Select Item hex values used to choose a list of items to choose to change your item hex.

2009.1.17 Update: 
The box rate of decline has done a more detailed management.
You can delete, add to or amend the value of each.
Screening of the need to find item.

2009.2.24
1, Increase user items view(MySQL).
Items name query the database is "Items.dll".
"Items.txt" reference information: "bb_items.txt".
2, Increase Local GM Local GM Management. 

*You need to .Net Framework 2.0 to run it.
*��Test MySQL Connection�� and ��User Items View (MySQL)�� This feature will need to install driver:MySQL Connector/Net is an ADO.NET driver for MySQL 5.2.5

MySQL Connector/Net is an ADO.NET driver for MySQL:
http://dev.mysql.com/downloads/connector/net/5.2.html